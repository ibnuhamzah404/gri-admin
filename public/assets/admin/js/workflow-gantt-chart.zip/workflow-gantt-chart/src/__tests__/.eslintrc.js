module.exports = {
	env: {
		jest: true
	},
	rules: {
		'jest/no-hooks': 'off',
	}
};
