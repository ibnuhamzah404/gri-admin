module.exports = {
	parserOptions: {
		project: [
			'./tsconfig.samples.json'
		]
	},
};
