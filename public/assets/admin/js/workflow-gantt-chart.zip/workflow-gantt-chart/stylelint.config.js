module.exports = {
	'extends': 'stylelint-config-standard',
	'ignoreFiles': '**/*.{js,ts}',
	'rules': {
		'indentation': 'tab',
	}
};
